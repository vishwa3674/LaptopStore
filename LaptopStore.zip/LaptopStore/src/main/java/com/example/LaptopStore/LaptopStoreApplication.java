package com.example.LaptopStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaptopStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaptopStoreApplication.class, args);
	}

}
